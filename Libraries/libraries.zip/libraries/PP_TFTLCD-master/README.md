# PP_TFTLCD
Biblioteca PP_TFTLCD - Arduino

Biblioteca modificada para utiliza��o com display LCD touch 2.4" e controlador ILI9335.